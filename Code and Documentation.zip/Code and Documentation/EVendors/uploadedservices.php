<?php

session_start();
$conn=mysqli_connect("localhost","root","","evendors");

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    header("location: login.php");
}

?>
<?php 

if(isset($_POST['delete_data']))
{
    $id=$_POST['delete_id'];
    $image=$_POST['delete_image'];

    $query_delete=" DELETE FROM insertservices WHERE service_id='$id'";
    $query_runn=mysqli_query($conn,$query_delete);
    
    if($query_runn)
    {
        unlink("uploads/".$image);
        $_SESSION['status']="Data Deleted Successfully";
        header("Location: uploadedservices.php");

    }
    else
    {
        $_SESSION['status']="Data Not Deleted";
        header("Location: uploadedservices.php");

    }



}


?>

<DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/dashboard.css">
    <script src="https://kit.fontawesome.com/2c4306dec0.js" crossorigin="anonymous"></script>   

    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Uploaded Services</title>
</head>


    
<body>
<header>
        <div id="logo">
            <img src="Images/Evendorslogo.png" alt="Logo">
        </div>
        
         
        
    </header>
    <div class="container">
    
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-info" style="background:#0076cb; color:white; padding:0 2px;" >
                        <h2>Uploaded Services</h2>
                    </div>
                    <diva class="card-body">
                    <?php
                       if(isset($_SESSION['status']) && $_SESSION!='')
                          {
                           ?>
                               <div class="alert alert-warning alert-dismissible fade show" role="alert">
                              <strong>Holy !</strong> <?php echo $_SESSION['status'];?>
                              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                             </div>
    
                               <?php
                                  unset($_SESSION['status']);
                             }
                            ?>
                         
                        <?php
                        $conn=mysqli_connect("localhost","root","","evendors");
                        $query=" SELECT *FROM insertservices ";
                        $query_run=mysqli_query($conn,$query);

                        ?>
                        <table class="table evendors ">
                            <thead>
                                <tr>
                                    <th>Service ID</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Address</th>
                                    <th>Specialty</th>
                                    <th>Image</th>
                                    <th>Edit</th>
                                    <th>Delete</th>



                                
                                </tr>


                            </thead>
                            <tbody>

                            <?php
                            if(mysqli_num_rows($query_run))
                            {
                                
                                foreach($query_run as $row)
                                {
                                    ?>
                                    <tr>
                                        <td><?php echo $row['service_id']; ?></td>
                                        <td><?php echo $row['title']; ?></td>
                                        <td><?php echo $row['descrip']; ?></td>
                                        <td><?php echo $row['shop_address']; ?></td>
                                        <td><?php echo $row['specialty']; ?></td>
                                        <td>
                                            <img src="<?php echo"uploads/". $row['images']; ?>" width="100px" alt="image">
                                        </td>
                                        <td>
                                            <a href="edit.php?id=<?php echo $row['service_id'];?>" class="btn btn-info">Edit</a>
                                        </td>
                                        <td>
                                        <!-- <a href="#" class="btn btn-danger">Delete</a> -->
                                          <form action="" method="post">

                                          <input type="hidden" name="delete_id" value="<?php echo $row['service_id']; ?>">
                                          <input type="hidden" name="delete_image" value="<?php echo $row['images']; ?>">
                                          <button type="submit" name="delete_data" class="btn btn-danger">Delete</button>



  
                                            
                                          </form>
                                        </td>
                                    </tr>
                                    <?php
                                }

                            }
                            else{
                                ?>
                                <tr>
                                    <td>
                                    <td>No Record Available</td>
                                    </td>
                                </tr>
                                <?php

                            }
                            ?>
                            


                            </tbody>
                        </table>

                    </diva>



























                </div>







            </div>





        </div>


    </div>
</body>
</html>
 