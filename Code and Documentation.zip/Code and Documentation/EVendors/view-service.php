
<?php 
session_start();
  ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/dashboard.css">
      <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


    
    <title>View Services</title>
</head>
<body>
    <div class="wrapper">
 
    <header>
        <div id="logo">
            <img src="Images/Evendorslogo.png" alt="Logo">
        </div>
        
    </header>

 
 
      <?php
 

 $conn=mysqli_connect("localhost","root","","evendors");

 $service_id=$_GET['id'];
 $sql=" SELECT *FROM insertservices WHERE service_id='$service_id' ";
     $query=mysqli_query($conn,$sql);
 
     if(mysqli_num_rows($query)>0)
     {
       while ($rows=mysqli_fetch_assoc($query)) {
         
 
 ?>
          <table>
            <tr>
              <td><h2><?php echo $rows['title']; ?></h2></td>
            </tr>
            <tr>
               
              <td><p><?php echo $rows['descrip']; ?></p></td>
            </tr>
            <tr>
              <td><h4><?php echo $rows['shop_address']; ?></h4></td><br>
               
            </tr>
            <tr>
              <td><h4><?php echo $rows['specialty']; ?></h4></td><br>
               
            </tr>
          </table>
           
<?php
      }
    }
    ?>
    <br> 
    <div class="second-sidebar">

    <a href="" class="btn btn-info">Send Messeage</a>
    <a href="" class="btn btn-info">Hire</a>






    </div>
         

    

         </div>
</body>
</html>