<?php 
   $conn=mysqli_connect("localhost","root","","evendors");
 ?>
<?php
//This script will handle login
session_start();

// check if the user is already logged in
if(isset($_SESSION['username']))
{
    header("location: dashboard.php");
    exit;
}
 


$username = $password = "";
$err = "";

// if request method is post
if ($_SERVER['REQUEST_METHOD'] == "POST"){
    if(empty(trim($_POST['username'])) || empty(trim($_POST['password'])))
    {
        $err = "Please enter username + password";
    }
    else{
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
    }


if(empty($err))
{
    $sql = "SELECT id, username, password FROM register WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $param_username);
    $param_username = $username;
    
    
    // Try to execute this statement
    if(mysqli_stmt_execute($stmt)){
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt))
                    {
                        if(password_verify($password, $hashed_password))
                        {
                            // this means the password is corrct. Allow user to login
                            session_start();
                            $_SESSION["username"] = $username;
                            $_SESSION["id"] = $id;
                            $_SESSION["loggedin"] = true;

                            //Redirect user to welcome page
                            header("location: dashboard.php");
                            
                        }
                    }

                }

    }
}    


}


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/signup.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
       
    <title>Login-EVendors Marketplace</title>
</head>
<body>
    <div class="container">
    
        <header>
            <div id="logo">
                <img src="Images/Evendorslogo.png" alt="Logo">
            </div>
        </header>
        </div>
        <div class="sign-up">

            <div class="sign-up-image">
                <img src="images/man.png" alt="The man">

            </div>
            <div  class="sign-up-form">
                <h2 id="signup-heading">Login</h2>
                <p id="signup-paragraph">Please fill in this form to Login.</p>
                <hr>
                
                <form action="" method="post">

                     
                      <input type="text" placeholder="Enter Your UserName" name="username" required>
                      <br><br>
                      <input type="password" placeholder="Enter Your Password" name="password" required>
                      <br><br>
 
                      <br><br>
                      <div class="clearfix">
                      <a href="home.php" class="cancelbtn">Cancel</a>
                        <button type="submit" class="signupbtn">Login</button>

                        <p>Do you Have an Accound? <a id="alreadylogin" href="signup.php">Sign Up</a></p>
                    
                  </form>
                </div>

         </div>



    
 
    


 



    
      
        </div>

  <Footer>
    <p>@2021-All Rights Reserved</p>
  </Footer>




</body>
</html> 





