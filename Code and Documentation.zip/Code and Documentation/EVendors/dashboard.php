<?php

session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    header("location: login.php");
}



?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/dashboard.css">
    <script src="https://kit.fontawesome.com/2c4306dec0.js" crossorigin="anonymous"></script>   
     <title>Dashboard-EVendors Marketplace</title>
</head>
<body>
<div class="container">
 
    <header>
        <div id="logo">
            <img src="Images/Evendorslogo.png" alt="Logo">
        </div>
        
        <ul>
        <li class="myusername"><i class="fas fa-user-circle" style="font-size:20px;color:#ffffff"></i><?php echo" Welcome: ". $_SESSION['username']?></li>
        </ul>
        
    </header>

<div class="mysidebar">
    <ul>
        <li><i class="fas fa-tachometer-alt"></i><a href="dashboard.php" class="dashboard">Dashboard</a></li>
        <li><i class="fas fa-briefcase"></i><a href="insertservices.php">Add Service</a></li>
        <li><i class="fas fa-upload"></i><a href="uploadedservices.php">Uploaded Services</a></li>
        <li><i class="fas fa-user-circle"></i><a href="#">Profile</a></li>
        <li><i class="far fa-envelope"></i><a href="#">Messages</a></li>
        <li><i class="fas fa-sign-out-alt"></i><a href="logout.php">Logout</a></li>


    </ul>
</div>


</div>

<Footer>
    <p>@2021-All Rights Reserved</p>
</Footer>
</body>

</html>