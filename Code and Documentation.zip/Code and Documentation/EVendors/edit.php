<?php

session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    header("location: login.php");
}

?>
<?php 
include("config.php");
 
 ?>
 
<?php 

if(isset($_POST['updatebtn']))
{
    $update_id=$_POST['edit_id'];
    $title=$_POST['title'];
    $descrip=$_POST['descrip'];
    $specialty=$_POST['specialty'];
	$shop_address=$_POST['shop_address'];
    $new_image=$_FILES['images']['name'];
    $old_image=$_POST['old_image'];
    

    


if($new_image!='')
{
    $update_filename=$_FILES['images']['name'];

}
else
{
    $update_filename= $old_image;

}
if(file_exists("uploads/".$_FILES['images']['name']))
{
    $filename=$_FILES['images']['name'];
    $_SESSION['status']="Image Already Exists".$filename;
    header('Location:uploadedservices.php');

}
else
{
    $query_update="UPDATE insertservices SET title='$title', descrip='$descrip', specialty='$specialty',shop_address='$shop_address',images='$update_filename' WHERE service_id='$update_id'";
    $query_update_run=mysqli_query($conn, $query_update);

    if($query_update_run)
    {
        if($_FILES['images']['name'] !='')
        {
            move_uploaded_file($_FILES["images"]["tmp_name"],"uploads/".$_FILES["images"]["name"]);
            unlink("uploads/".$old_image);

        }
        $_SESSION['status']="Data Updated Successfully";
        header("Location: uploadservices.php");
    }
    else
    {
         $_SESSION['status']="Data Not Updated.... Try Again";
        header("Location: edit.php");
    }

}
}


?>
 
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="//cdn.ckeditor.com/4.16.0/basic/ckeditor.js"></script>
    <link rel="stylesheet" href="CSS/dashboard.css">
 


    <title>Edit Service</title>
</head>
<body>


<div class="container"> 
<header>
        <div id="logo">
            <img src="Images/Evendorslogo.png" alt="Logo">
        </div>
    </div>
</header>

 


</div>
<div class="service_form">
<h2 class="add-service">Edit Your Service</h2>
<p class="signup-paragraph">Use Below Form to Edit your Service</p>
<hr>
<?php
 

$conn=mysqli_connect("localhost","root","","evendors");
 
$service_id=$_GET['id'];
$query=" SELECT *FROM insertservices WHERE service_id='$service_id' ";
$query_run=mysqli_query($conn, $query);

if(mysqli_num_rows($query_run)> 0)
{
    foreach($query_run as $row)
    {
    ?>

<form action="" method="post" enctype="multipart/form-data">


<input type="hidden" name="edit_id" value="<?php echo $row['service_id']   ?>" size="60">

<label for="title">Title</label>
<input type="text" name="title" value="<?php echo $row['title']   ?>" size="60">
<br><br>

<label for="descrip">description</label>
<textarea name="descrip" value="<?php echo $row['descrip']   ?>" id="article_editor"></textarea>
<br><br>


<label for="location">Address</label>
<input type="text" name="shop_address" value="<?php echo $row['shop_address']   ?>" size="50">
<br><br>

<label for="specialty">Specialty</label>
<input type="text" name="specialty" value="<?php echo $row['specialty']   ?>" value="<?php echo $row['specialty']   ?>" >
<br><br>



<label for="image" >Featured Image</label><br>
<input type="file" name="images">
<input type="hidden" name="old_image" value="<?php echo $row['images'];   ?>" ><br>
<img src="<?php echo "uploads/".$row['images']; ?>" alt="image" width="100px">
<br>




<div>
<a href="uploadedservices.php" class="back">Back</a>
<button type="submit" name="updatebtn" class="submitbtn">Update</button>
</div>




        
        

        
    
</form>

    <?php
    }

}
else{
    echo "No Record Available";

}
?>



</div>
</div>







<script>
    CKEDITOR.replace('article_editor');
</script>
<Footer>
    <p>@2021-All Rights Reserved</p>
</Footer>
</body>
</html>