
 


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/home.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
       
    <title>EVendors Marketplace</title>

</head>
<body>
<div class="container">
    
<header>
    <div id="logo">
        <img src="Images/Evendorslogo.png" alt="Logo">
    </div>
    
<div class="registration-menu">
    <nav>
        <input type="checkbox" id="check">
      <label for="check" class="toggle-menu">
        <i class="fa fa-bars" aria-hidden="true"></i>
      </label>
        <ul>
            
            <li><a id="project-button" href="#">Post a Project</a></li>
            <li><a class="home" href="#">Home</a></li>
            <li><a class="about" href="">About</a></li>
            <li><a  href="login.php">LogIn</a></li>
            <li><a  href="Signup.php">SignUp</a></li>
       </ul>
    </nav>
</div>

</header>
 
<div class="services-menu">
<nav>
    <ul>
        <li><a href="#">Plumber</a></li>
        <li><a href="#">Electrician</a></li>
        <li><a href="#">Builder</a></li>
        <li><a href="#">Painter</a></li>
        <li><a href="#">Home Cleaner</a></li>
        <li><a href="#">Mechanic</a></li>
    </ul>
</nav>

</div>


    <div id="front-page-image">
        <img src="images/Evendorsfrontpage.png" alt="front page image">
    </div>

<div class="services-defined">
    <div class="box box1">
        <img src="images/expert.svg" alt="experts">
        <p>Get Inspired from New Experts</p>
    </div>
    <div class="box box2">
        <img src="images/screw and wrench.svg" alt="Find a professional">
        <p>Find a Professional</p>

    </div>
    <div class="box">
        <img src="images/hire.svg" alt="hire">
        <p>HIRE Multi-Vendors from One Place</p>
    </div>

</div>
<h2 id="findvendors">Find Top Vendors</h2>
    <hr>
 
    
<div class="services" >
 <div class="service-item">
        <img src="images/plumber.svg" alt="plumber">
        <p>Plumbers</p>
    </div>
    <div class="service-item">
        <i class="fas fa-sign-in-alt"></i>
        <img src="images/electrician.svg" alt="electrician">
        <p>Electricians</p>
    </div>
    <div class="service-item">
        <img src="images/vacuum.svg" alt="Home Cleaner">
        <p>Home Cleaners</p>
    </div>
    <div class="service-item">
        <img src="images/painter.svg" alt="Painter">
        <p>Painters</p>
    </div>
    <div class="service-item">
        <img src="images/mechanic.svg" alt="Mechanic">
        <p>Mechanics</p>
    </div>
    <div class="service-item">
        <img src="images/builder.svg" alt="Builder">
        <p>Builders</p>
    </div>
</div>
 
<h2 id="findvendors">Explore Services by Experianced Vendors</h2>
<hr>
 <?php 
require_once "config.php";

$sql="SELECT * FROM insertservices";
    $query=mysqli_query($conn,$sql);

    if(mysqli_num_rows($query)>0)
    {
      while ($rows=mysqli_fetch_assoc($query)) {
        $service_id=$rows['service_id'];

?>
 <div class="card-container">

<div class="card-section">
<div class="card">
<?php


    $sql2=" SELECT images FROM insertservices WHERE service_id='$service_id'";
    $query2=mysqli_query($conn,$sql2);
    if(mysqli_num_rows($query2)>0)
    {
      $row=mysqli_fetch_assoc($query2); 
        $photo=$row['images'];
        echo  '<img class="images" src="uploads/'.$photo.'">'; }?>

    
  <h4><b><?php echo $rows['title']; ?></b></h4> 
  <p><?php echo $rows['shop_address'];?></p> 
  <p><?php echo '<a href="view-service.php?id='.$rows['service_id'].'"   class="btn">View </a><br>'; ?></p><br>
</div>
</div>
</div>
 
<?php
      }
    }
    ?>


  

<div class="how-it-works">
    <Div class="getting-work1">
        <h2>Getting Work Done<br> Has Never been<br> Easier</h2>
    <ul>
      <li> Mached with Expert Vendors in Minutes</li>
      <li> 24/7 Didicated Customers Support</li>
      <li> Quick Service</li>  
    </ul>
    </Div>

    <div class="getting-work2">
        <img src="images/man.png" alt="">
    </div>

</div>

<h2 id="our-team">Our Team</h2>
<hr>
 <div class="team">
    
        <div class="mybio">
             <img src="Images/Faisal.jpg" alt="">
            <h3>Muhammad Faisal</h3>
            <p>(Fa17-BSE-030)</p>

        </div>
        <div class="mybio">
             <img src="Images/huraira.jpg" alt="">
            <h3>Huraira Ahmer</h3>
            <p>(SP18-BSE-019)</p>

        </div>

    </div>
</div>




</div>

<Footer>
    <p>@2021-All Rights Reserved</p>
</Footer>
</div>
</body>
</html> 

