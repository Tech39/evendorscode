<?php

session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !==true)
{
    header("location: login.php");
}

?>
<?php 
   $conn=mysqli_connect("localhost","root","","evendors");
 ?>

<?php
 
if(isset($_POST['submit'])){

    $title=$_POST['title'];
    $descrip=$_POST['descrip'];
    $specialty=$_POST['specialty'];
	$shop_address=$_POST['shop_address'];
    $images=$_FILES['images']['name'];

    
 


    if(file_exists("uploads/".$_FILES['images']['name']))
    {
        $filename=$_FILES['images']['name'];
        $_SESSION['status']="Image Already Exists".$filename;
        header('Location:insertservices.php');

    }
    else{
        $query="INSERT INTO insertservices (title,descrip,specialty,shop_address,images) VALUES ('$title','$descrip','$specialty','$shop_address','$images')";
        $query_run=mysqli_query($conn,$query);
    
        if($query_run)
        {
            move_uploaded_file($_FILES["images"]["tmp_name"],"uploads/".$_FILES["images"]["name"]);
             $_SESSION['status']="Insert Successfully";
            header('Location:insertservices.php');
    
        }
        else{
            $_SESSION['status']="Insertion Failed... Try Again";
            header('Location:insertservices.php');
    
        }

    }
}

   







?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="//cdn.ckeditor.com/4.16.0/basic/ckeditor.js"></script>
    <link rel="stylesheet" href="CSS/dashboard.css">
 


    <title>Add Service</title>
</head>
<body>


<div class="container"> 
<header>
        <div id="logo">
            <img src="Images/Evendorslogo.png" alt="Logo">
        </div>
    </div>
</header>

 


</div>
<div class="service_form">
<h2 class="add-service">ADD A SERVICE</h2>
<p class="signup-paragraph">Fill this Form to add your Service</p>
<hr>


 
<form action="" method="post" enctype="multipart/form-data">
 

<label for="title">Title</label>
<input type="text" name="title" placeholder="Enter Your Service Title" size="60">
<br><br>

<label for="descrip">description</label>
<textarea name="descrip" rows="4" cols="50" placeholder="Define your Service" id="article_editor"></textarea>
<br><br>


<label for="location">Address</label>
<input type="text" name="shop_address" placeholder="Enter Shop Address" size="50">
<br><br>

<label for="specialty">Specialty</label>
<input type="text" name="specialty" placeholder="Enter your Specialty">
<br><br>



<label for="image" >Featured Image</label>
<input type="file" accept="uploads/*" name="images">



<div>
<a href="dashboard.php" class="back">Back</a>
<button type="submit" name="submit" class="submitbtn">Submit</button>
</div>




        
        

        
    
</form>
</div>
</div>







<script>
    CKEDITOR.replace('article_editor');
</script>

</body>
<Footer>
    <p>@2021-All Rights Reserved</p>
</Footer>
</html>